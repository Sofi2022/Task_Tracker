package tasks;

public enum TaskStatus {
    NEW,
    IN_PROGRESS,
    DONE;
}
