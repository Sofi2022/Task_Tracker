package manager;

public enum TaskTypes {
    TASK,
    SUBTASK,
    EPIC;
    }

